package main;/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.List;
import java.util.ArrayList;
import java.sql.*;

import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseQuery {

    // Method to fetch users without enrollments
    public static void fetchUsersWithoutEnrollments(DefaultTableModel model) throws SQLException 
    {
        String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
        String username = "root"; // Replace with your database username
        String password = "SAUDkhan"; // Replace with your database password

        String query = """
                SELECT 
                    Users.Name, 
                    Users.Role, 
                    Users.Email
                FROM 
                    Users
                LEFT JOIN 
                    Enrollments 
                ON 
                    Users.UserID = Enrollments.UserID
                WHERE 
                    Enrollments.EnrollmentID IS NULL;
            """;

        try (Connection conn = DriverManager.getConnection(url, username, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            // Clear the table for fresh data
            model.setRowCount(0);
 model.setColumnIdentifiers(new String[]{"Name", "Role","Email"});

            // Populate the table with data
            while (rs.next()) {
                String name = rs.getString("Name");
                String role = rs.getString("Role");
                String passwordData = rs.getString("Email");
                model.addRow(new Object[]{name, role, passwordData});
            }
        }
    }

    // Method to fetch all users
    public static void fetchAllUsers(DefaultTableModel model) throws SQLException {
    // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
        String username = "root"; // Replace with your database username
        String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch all user details (excluding Password)
    String query = "SELECT UserID, Name, Email, Role, DateOfBirth, JoinDate FROM Users;";

    try (Connection conn = DriverManager.getConnection(url, username, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        // Clear the table for fresh data
        model.setRowCount(0);
model.setColumnIdentifiers(new String[]{"UserID", "Name","Email","Role","DateOfBirth","JoinDate"});

        // Populate the table with data from ResultSet
        while (rs.next()) {
            int userId = rs.getInt("UserID");
            String name = rs.getString("Name");
            String email = rs.getString("Email");
            String role = rs.getString("Role");
            String dateOfBirth = rs.getString("DateOfBirth");
            String joinDate = rs.getString("JoinDate");

            // Add row to table model
            model.addRow(new Object[]{userId, name, email, role, dateOfBirth, joinDate});
        }
    }
}

// Method to fetch top 5 users by CourseID and Score
    public static void fetchTop5ByCourseID(DefaultTableModel model, int courseId) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
        String username = "root"; // Replace with your database username
        String password = "SAUDkhan"; // Replace with your database password

        String query = """
                SELECT U.Name, E.Score
                    FROM Enrollments E
                    JOIN Users U ON E.UserID = U.UserID
                    WHERE E.CourseID = ?
                    ORDER BY E.Score DESC
                    LIMIT 5;
                
            """;

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, courseId); // Set the CourseID parameter

            try (ResultSet rs = stmt.executeQuery()) {
                // Clear the table for fresh data
                model.setRowCount(0);
model.setColumnIdentifiers(new String[]{"Student Name", "Score"});

                // Populate the table with data
                while (rs.next()) {
                    String name = rs.getString("Name");
                    int score = rs.getInt("Score");
                    model.addRow(new Object[]{name, score});
                }
            }
        }
    }
    // Static method to fetch user count
public static void fetchUserCount(DefaultTableModel model) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    String query = "SELECT COUNT(*) AS UserCount FROM Users;";

    try (Connection conn = DriverManager.getConnection(url, username, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        model.setRowCount(0); // Clear the table before displaying new data

        if (rs.next()) {
            int userCount = rs.getInt("UserCount");
            model.addRow(new Object[]{"Total Users", userCount});
        } else {
            JOptionPane.showMessageDialog(null, "No Data Found.");
        }
    }
}
// Static method to fetch instructor ratings
public static void fetchInstructorRatings(DefaultTableModel model) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    String query = """
        SELECT I.Name AS InstructorName, AVG(F.Rating) AS AverageRating
        FROM Feedback F
        JOIN Courses C ON F.CourseID = C.CourseID
        JOIN Instructors I ON C.InstructorID = I.InstructorID
        GROUP BY I.Name;
    """;

    try (Connection conn = DriverManager.getConnection(url, username, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        model.setRowCount(0); // Clear the table before displaying new data

        // Add column names specific to this query
        model.setColumnIdentifiers(new String[]{"Instructor Name", "Average Rating"});

        // Populate the table
        while (rs.next()) {
            String instructorName = rs.getString("InstructorName");
            double averageRating = rs.getDouble("AverageRating");
            model.addRow(new Object[]{instructorName, averageRating});
        }
    }
}
public static void fetchBestInstructorByCourseID(DefaultTableModel model, int courseId) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch the best instructor for the given course
    String query = """
        SELECT I.Name AS InstructorName, AVG(F.Rating) AS AverageRating
        FROM Feedback F
        JOIN Courses C ON F.CourseID = C.CourseID
        JOIN Instructors I ON C.InstructorID = I.InstructorID
        WHERE C.CourseID = ?
        GROUP BY I.Name
        ORDER BY AverageRating DESC;
    """;

    // Execute the query
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setInt(1, courseId); // Set the Course ID parameter

        try (ResultSet rs = pstmt.executeQuery()) {
            model.setRowCount(0); // Clear the table for fresh data

            // Set table column names
            model.setColumnIdentifiers(new String[]{"Instructor Name", "Average Rating"});

            // Populate the table with query results
            if (rs.next()) {
                do {
                    String instructorName = rs.getString("InstructorName");
                    double averageRating = rs.getDouble("AverageRating");
                    model.addRow(new Object[]{instructorName, averageRating});
                } while (rs.next());
            } else {
                JOptionPane.showMessageDialog(null, "No data found for the given Course ID.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
}
public static void fetchCoursesByCategoryWithEnrollments(DefaultTableModel model) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch courses by category with enrollments greater than 1
    String query = """
        SELECT CAT.CategoryName, C.Title AS CourseTitle, COUNT(E.UserID) AS Enrollments
        FROM Courses C
        JOIN Categories CAT ON C.CategoryID = CAT.CategoryID
        JOIN Enrollments E ON C.CourseID = E.CourseID
        GROUP BY CAT.CategoryName, C.Title
        HAVING COUNT(E.UserID) = 1;
    """;

    // Execute the query
    try (Connection conn = DriverManager.getConnection(url, username, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        model.setRowCount(0); // Clear the table for fresh data

        // Set table column names
        model.setColumnIdentifiers(new String[]{"Category Name", "Course Title", "Enrollments"});

        // Populate the table with query results
        while (rs.next()) {
            String categoryName = rs.getString("CategoryName");
            String courseTitle = rs.getString("CourseTitle");
            int enrollments = rs.getInt("Enrollments");
            model.addRow(new Object[]{categoryName, courseTitle, enrollments});
        }
    }
}
public static void fetchCompletedCoursesForUser(DefaultTableModel model, int userId) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch completed courses for the given user in 2024
    String query = """
        SELECT C.Title AS CourseTitle, E.CompletionStatus, E.EnrollmentDate
        FROM Enrollments E
        JOIN Courses C ON E.CourseID = C.CourseID
        WHERE E.UserID = ? AND E.CompletionStatus = 'Completed';
    """;

    // Execute the query
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {

        pstmt.setInt(1, userId); // Set the UserID parameter
        try (ResultSet rs = pstmt.executeQuery()) {
            model.setRowCount(0); // Clear the table for fresh data

            // Set table column names
            model.setColumnIdentifiers(new String[]{"Course Title", "Completion Status", "Enrollment Date"});

            // Populate the table with query results
            while (rs.next()) {
                String courseTitle = rs.getString("CourseTitle");
                String completionStatus = rs.getString("CompletionStatus");
                Date enrollmentDate = rs.getDate("EnrollmentDate");
                model.addRow(new Object[]{courseTitle, completionStatus, enrollmentDate});
            }
        }
    }
}
public static String[] fetchUserDetails(int userId) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch user details
    String query = "SELECT Name, Email FROM Users WHERE UserID = ?";

    // Execute the query
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {

        pstmt.setInt(1, userId); // Set the UserID parameter
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                String name = rs.getString("Name");
                String email = rs.getString("Email");
                return new String[]{name, email}; // Return user details
            }
        }
    }
    return null; // Return null if no user is found
}
public static void fetchFeedbackForCourse(DefaultTableModel model, int courseId) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch feedback for a specific course
    String query = """
        SELECT C.Title AS CourseTitle, U.Name AS UserName, F.Rating, F.Comments, F.FeedbackDate
        FROM Feedback F
        JOIN Users U ON F.UserID = U.UserID
        JOIN Courses C ON F.CourseID = C.CourseID
        WHERE C.CourseID = ?;
    """;

    // Execute the query
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {

        pstmt.setInt(1, courseId); // Set the Course ID parameter
        try (ResultSet rs = pstmt.executeQuery()) {
            model.setRowCount(0); // Clear the table for fresh data

            // Set table column names
            model.setColumnIdentifiers(new String[]{"Course Title", "User Name", "Rating", "Comments", "Feedback Date"});

            // Populate the table with query results
            while (rs.next()) {
                String courseTitle = rs.getString("CourseTitle");
                String userName = rs.getString("UserName");
                int rating = rs.getInt("Rating");
                String comments = rs.getString("Comments");
                Date feedbackDate = rs.getDate("FeedbackDate");
                model.addRow(new Object[]{courseTitle, userName, rating, comments, feedbackDate});
            }
        }
    }
}
public static void fetchAverageScoreForAssessmentsByCourse(DefaultTableModel model, int courseId) throws SQLException {
        // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

        // SQL query to fetch the average score for assessments for a specific course
        String query = """
            SELECT A.Title AS AssessmentTitle, AVG(R.Score) AS AverageScore
            FROM Assessments A
            JOIN AssessmentResults R ON A.AssessmentID = R.AssessmentID
            JOIN Courses C ON A.CourseID = C.CourseID
            WHERE C.CourseID = ?  -- Use the user-provided Course ID
            GROUP BY A.Title;
        """;

        // Execute the query
        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, courseId);  // Set the Course ID in the query

            try (ResultSet rs = stmt.executeQuery()) {
                model.setRowCount(0); // Clear the table for fresh data

                // Set table column names
                model.setColumnIdentifiers(new String[]{"Assessment Title", "Average Score"});

                // Populate the table with query results
                while (rs.next()) {
                    String assessmentTitle = rs.getString("AssessmentTitle");
                    double averageScore = rs.getDouble("AverageScore");
                    model.addRow(new Object[]{assessmentTitle, averageScore});
                }
            }
        }
    }
public static void insertUser(String name, String email, String password, String dateOfBirth, String role) throws SQLException {
        // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

        // SQL query to insert a new user
        String query = """
            INSERT INTO Users (Name, Email, Password, DateOfBirth, JoinDate, Role)
                    VALUES (?, ?, ?, ?, NOW(), ?);
                
        """;

        // Execute the query using a PreparedStatement
        try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);          // Set Name
            stmt.setString(2, email);         // Set Email
            stmt.setString(3, password);      // Set Password
            stmt.setString(4, dateOfBirth);   // Set Date of Birth
            stmt.setString(5, role);          // Set Role

            // Execute the insert query
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new user was inserted successfully!");
            }
        }
    }
public static void insertEnrollment(int userId, int courseId, Date enrollmentDate, String completionStatus) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    // SQL query to insert a new enrollment
    String query = """
        INSERT INTO Enrollments (UserID, CourseID, EnrollmentDate, CompletionStatus)
        VALUES (?, ?, ?, ?);
    """;

    // Execute the query using a PreparedStatement
    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, userId);               // Set UserID
        stmt.setInt(2, courseId);             // Set CourseID
        stmt.setDate(3, enrollmentDate);      // Set Enrollment Date
        stmt.setString(4, completionStatus);  // Set Completion Status

        // Execute the insert query
        int rowsInserted = stmt.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Enrollment was inserted successfully!");
        }
    }
}
public static void insertFeedback(int userId, int courseId, int rating, String comments) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    // SQL query to insert feedback for a specific user and course
    String query = """
       INSERT INTO Feedback (UserID, CourseID, Rating, Comments, FeedbackDate)
               VALUES (?, ?, ?, ?, NOW());
           
    """;

    // Execute the query using a PreparedStatement
    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        // Set the parameters for userId, courseId, rating, and comments
        stmt.setInt(1, userId);
        stmt.setInt(2, courseId);
        stmt.setInt(3, rating);   // Rating provided by the user
        stmt.setString(4, comments); // Comments provided by the user

        // Execute the insert query
        int rowsInserted = stmt.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Feedback submitted successfully!");
        }
    }
}
 
public static void updateEnrollmentScore(int enrollmentId, int courseId, int currentScore) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    // SQL query to update the score by adding 20 to the current score
    String query = """
        UPDATE Enrollments
        SET Score = Score + 20
        WHERE EnrollmentID = ? AND CourseID = ?;
    """;

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        // Set the parameters for EnrollmentID and CourseID
        stmt.setInt(1, enrollmentId);
        stmt.setInt(2, courseId);

        // Execute the update query
        int rowsUpdated = stmt.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Score updated successfully!");
        } else {
            System.out.println("No rows updated. Please check the provided information.");
        }
    }
}
public static void applyDiscountToEligibleUsers() throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    // SQL query to apply a 20% discount for users enrolled in 3 or more courses
    String query = """
        UPDATE PaymentDetails
        SET Amount = Amount * 0.8
        WHERE UserID IN (
            SELECT UserID
            FROM Enrollments
            GROUP BY UserID
            HAVING COUNT(DISTINCT CourseID) >= 3
        );
    """;

    // Execute the update query
    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        // Execute the query
        int rowsUpdated = stmt.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Discount applied successfully to " + rowsUpdated + " users!");
        } else {
            System.out.println("No users met the criteria for a discount.");
        }
    }
}
public static void fetchDiscountedUsers(DefaultTableModel model) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String password = "SAUDkhan"; // Replace with your database password

    // SQL query to fetch discounted users
    String query = """
        SELECT 
            pd.UserID, 
            pd.Amount, 
            COUNT(DISTINCT e.CourseID) AS TotalCourses 
        FROM 
            PaymentDetails pd
        JOIN 
            Enrollments e 
        ON 
            pd.UserID = e.UserID
        GROUP BY 
            pd.UserID, pd.Amount
        HAVING 
            COUNT(DISTINCT e.CourseID) >= 3;
    """;

    try (Connection conn = DriverManager.getConnection(url, username, password);
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {

        // Clear the table for fresh data
        model.setRowCount(0);
        model.setColumnIdentifiers(new String[]{"UserID", "Amount", "Total Courses"});

        // Populate the table with data
        while (rs.next()) {
            int userId = rs.getInt("UserID");
            double amount = rs.getDouble("Amount");
            int totalCourses = rs.getInt("TotalCourses");

            // Add a row to the table model
            model.addRow(new Object[]{userId, amount, totalCourses});
        }
    }
}
public static boolean updateInstructorRating(int instructorId) throws SQLException {
    // Database connection parameters
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    // SQL query to check and update instructor rating
    String query = """
        UPDATE Instructors
        SET Rating = Rating + 0.5
        WHERE InstructorID = ? AND NOT EXISTS (
            SELECT 1
            FROM Feedback
            WHERE InstructorID = ? AND Rating < 3.0
        );
    """;

    // Execute the update query
    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        // Set the Instructor ID in the query
        stmt.setInt(1, instructorId);
        stmt.setInt(2, instructorId);

        // Execute the update query
        int rowsUpdated = stmt.executeUpdate();
        return rowsUpdated > 0; // Return true if the rating was updated
    }
}

public static List<String[]> fetchInactiveUsers(int intervalDays) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    String query = """
        SELECT UserID, Name, JoinDate, Role
                FROM Users
                WHERE UserID NOT IN (
                    SELECT DISTINCT UserID FROM Enrollments
                )
                AND JoinDate < DATE_SUB(NOW(), INTERVAL ? DAY)
                AND Role = 'Student';
            
    """;

    List<String[]> users = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, intervalDays); // Set interval days
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            String[] user = {
                String.valueOf(rs.getInt("UserID")),
                rs.getString("Name"),
                rs.getString("JoinDate"),
                rs.getString("Role")
            };
            users.add(user); // Add user details to the list
        }
    }

    return users; // Return list of inactive users
}
public static void deleteInactiveUsers(int intervalDays) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    String query = """
        DELETE FROM Users
                WHERE UserID NOT IN (
                    SELECT DISTINCT UserID FROM Enrollments
                )
                AND JoinDate < DATE_SUB(NOW(), INTERVAL ? DAY)
                AND Role = 'Student';
            
    """;

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, intervalDays); // Set interval days
        int rowsDeleted = stmt.executeUpdate();
        System.out.println("Deleted " + rowsDeleted + " inactive users.");
    }
}
public static List<String[]> fetchCoursesForDeletion(double rating) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    String query = """
        SELECT CourseID, title
        FROM Courses
        WHERE CourseID NOT IN (
            SELECT DISTINCT CourseID
            FROM Feedback
            WHERE Rating >= ?
        );
    """;

    List<String[]> courses = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setDouble(1, rating); // Set rating threshold

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            String courseId = String.valueOf(rs.getInt("CourseID"));
            String name = rs.getString("title");

            courses.add(new String[]{courseId, name});
        }
    }

    return courses;
}

public static void deleteCourses(double rating) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    String query = """
        DELETE FROM Courses
        WHERE CourseID NOT IN (
            SELECT DISTINCT CourseID
            FROM Feedback
            WHERE Rating >= ?
        );
    """;

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setDouble(1, rating); // Set rating threshold

        int rowsDeleted = stmt.executeUpdate();
        System.out.println(rowsDeleted + " courses deleted.");
    }
}
public static List<String[]> retrieveUserAssessments(int userId) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    String query = """
        SELECT AssessmentID, ResultID,score
        FROM AssessmentResults
        WHERE UserID = ?
    """;

    List<String[]> assessments = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, userId);

        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            String assessmentId = String.valueOf(rs.getInt("AssessmentID"));
            String resultId = String.valueOf(rs.getInt("ResultID"));
   String sc = String.valueOf(rs.getInt("score"));
            assessments.add(new String[]{assessmentId, resultId,sc}); // Add AssessmentID and ResultID
        }
    }

    return assessments;
}
public static void updateAssessmentScoreByUser(int userId, int assessmentId, double score) throws SQLException {
    String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
    String username = "root"; // Replace with your database username
    String passwordDb = "SAUDkhan"; // Replace with your database password

    String query = """
        UPDATE AssessmentResults
        SET Score = ?
        WHERE UserID = ? AND AssessmentID = ?
    """;

    try (Connection conn = DriverManager.getConnection(url, username, passwordDb);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setDouble(1, score);
        stmt.setInt(2, userId);
        stmt.setInt(3, assessmentId);

        int rowsUpdated = stmt.executeUpdate();
        System.out.println(rowsUpdated + " row(s) updated.");
    }
}



    // Add more methods for different queries as needed


    public static boolean validateLogin(String email, String password) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/CoursePlatformNew?";
        String username = "root"; // Replace with your database username
        String passwordDb = "SAUDkhan"; // Replace with your database password

        Connection conn = DriverManager.getConnection(url, username, passwordDb);
        String sql = "SELECT Role FROM Users WHERE Email = ? AND Password = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, email);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            String role = rs.getString("Role");
            if ("Admin".equalsIgnoreCase(role)) {
                return true; // login success for admin
            } else {
                JOptionPane.showMessageDialog(null, "Access Denied: Only Admins can login.");
                return false;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Invalid Email or Password.");
            return false;
        }

    }

    public static void insertintoUser(String name, String email, String password, String dob, String role) throws SQLException {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=CoursePlatform;encrypt=true;trustServerCertificate=true";
        String username = "db";  // Replace with your database username
        String passwordDb = "111";  // Replace with your database password
        Connection conn = DriverManager.getConnection(url, username, passwordDb);
        String sql = "INSERT INTO Users (Name, Email, Password, DateOfBirth, JoinDate, Role) VALUES (?, ?, ?, ?, CURDATE(), ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, name);
        stmt.setString(2, email);
        stmt.setString(3, password);
        stmt.setDate(4, java.sql.Date.valueOf(dob));
        stmt.setString(5, role);
        stmt.executeUpdate();
    }

}





