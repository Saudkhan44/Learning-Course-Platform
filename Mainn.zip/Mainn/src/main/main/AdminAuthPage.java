package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminAuthPage extends JDialog {
    private boolean loginSuccessful = false;

    public AdminAuthPage(Frame parent) {
        super(parent, "Admin Login", true); // true = modal
        setSize(350, 250);
        setLocationRelativeTo(parent);
        setLayout(new GridLayout(4, 2, 10, 10));
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JTextField emailField = new JTextField();
        JPasswordField passField = new JPasswordField();

        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Password:"));
        add(passField);
        add(new JLabel()); // spacer

        JButton loginBtn = new JButton("Login");
        add(loginBtn);

        loginBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            String pass = new String(passField.getPassword());

            if (checkAdminLogin(email, pass)) {
                loginSuccessful = true;
                JOptionPane.showMessageDialog(this, "Login Successful!");
                dispose(); // Close the dialog
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials or not an admin.");
            }
        });
    }

    public boolean isLoginSuccessful() {
        return loginSuccessful;
    }

    private boolean checkAdminLogin(String email, String password) {
        try (Connection conn = connect()) {
            String query = "SELECT * FROM Users WHERE Email=? AND Password=? AND Role='Admin'";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println("Login Error: " + e.getMessage());
            return false;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Connection connect() throws Exception {
        String url = "jdbc:mysql://localhost:3306/CoursePlatform";
        String user = "root";    // your DB username
        String pass = "";        // your DB password
        return DriverManager.getConnection(url, user, pass);
    }
}
