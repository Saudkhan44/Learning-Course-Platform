//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package main;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Mainn {
    private static JFrame frame1;

    public Mainn() {
    }

    public static void main(String[] args) {
        // Step 1: Create the main frame but keep it hidden until login
        frame1 = new JFrame("Professional GUI");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setSize(500, 400);

        JPanel gradientPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(
                        0.0F, 0.0F, new Color(50, 150, 250),
                        0.0F, (float) this.getHeight(), Color.LIGHT_GRAY
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
            }
        };

        gradientPanel.setLayout(new GridBagLayout());
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        buttonPanel.setOpaque(false);

        JButton addButton = createStyledButtonn("Add");
        JButton selectButton = createStyledButtonn("Select");
        JButton updateButton = createStyledButtonn("Update");
        JButton deleteButton = createStyledButtonn("Delete");

        buttonPanel.add(addButton);
        buttonPanel.add(selectButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);

        gradientPanel.add(buttonPanel);
        frame1.add(gradientPanel);

        selectButton.addActionListener((e) -> openSelectQueriesFrame());
        addButton.addActionListener((e) -> openAddFrame());
        updateButton.addActionListener((e) -> openUpdateFrame());
        deleteButton.addActionListener((e) -> openDeleteFrame());

        frame1.setLocationRelativeTo(null);
        frame1.setVisible(false);  // Only show after login

        // Step 2: Show login/register options
        showEntryChoice(); // You’ll define this method next
    }


    public static void showEnrollmentDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Enrollment Details", true);
        dialog.setSize(400, 250);
        dialog.setLayout(new GridLayout(5, 2));
        dialog.getContentPane().setBackground(new Color(240, 240, 240));
        JLabel userIdLabel = new JLabel("User ID:");
        final JTextField userIdField = new JTextField();
        JLabel courseIdLabel = new JLabel("Course ID:");
        final JTextField courseIdField = new JTextField();
        JLabel enrollmentDateLabel = new JLabel("Enrollment Date (Auto):");
        final JTextField enrollmentDateField = new JTextField();
        enrollmentDateField.setEditable(false);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String currentDate = dateFormat.format(new Date());
        enrollmentDateField.setText(currentDate);
        userIdLabel.setForeground(new Color(0, 102, 204));
        courseIdLabel.setForeground(new Color(0, 102, 204));
        enrollmentDateLabel.setForeground(new Color(0, 102, 204));
        dialog.add(userIdLabel);
        dialog.add(userIdField);
        dialog.add(courseIdLabel);
        dialog.add(courseIdField);
        dialog.add(enrollmentDateLabel);
        dialog.add(enrollmentDateField);
        JButton enrollButton = new JButton("Enroll");
        enrollButton.setBackground(new Color(34, 139, 34));
        enrollButton.setForeground(Color.WHITE);
        dialog.add(new JLabel());
        dialog.add(enrollButton);
        enrollButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int userId = Integer.parseInt(userIdField.getText());
                    int courseId = Integer.parseInt(courseIdField.getText());
                    String enrollmentDateStr = enrollmentDateField.getText();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date utilDate = dateFormat.parse(enrollmentDateStr);
                    java.sql.Date enrollmentDate = new java.sql.Date(utilDate.getTime());
                    String completionStatus = "Not Complete";
                    double score = (double)0.0F;
                    DatabaseQuery.insertEnrollment(userId, courseId, enrollmentDate, completionStatus);
                    JOptionPane.showMessageDialog(dialog, "Enrollment added successfully!");
                    dialog.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    private static void openInsertUserFrame() {
        JFrame insertUserFrame = new JFrame("Insert User Data");
        insertUserFrame.setDefaultCloseOperation(2);
        insertUserFrame.setSize(400, 300);
        insertUserFrame.setLayout(new GridLayout(6, 2));
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        JTextField dobField = new JTextField();
        JLabel roleLabel = new JLabel("Role:");
        JTextField roleField = new JTextField();
        JButton submitButton = new JButton("Insert User");
        insertUserFrame.add(nameLabel);
        insertUserFrame.add(nameField);
        insertUserFrame.add(emailLabel);
        insertUserFrame.add(emailField);
        insertUserFrame.add(passwordLabel);
        insertUserFrame.add(passwordField);
        insertUserFrame.add(dobLabel);
        insertUserFrame.add(dobField);
        insertUserFrame.add(roleLabel);
        insertUserFrame.add(roleField);
        insertUserFrame.add(submitButton);
        submitButton.addActionListener((e) -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            String dateOfBirth = dobField.getText();
            String role = roleField.getText();
            if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty() && !dateOfBirth.isEmpty() && !role.isEmpty()) {
                try {
                    DatabaseQuery.insertUser(name, email, password, dateOfBirth, role);
                    JOptionPane.showMessageDialog(insertUserFrame, "User inserted successfully!");
                    insertUserFrame.dispose();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(insertUserFrame, "Error inserting user: " + ex.getMessage(), "Error", 0);
                }

            } else {
                JOptionPane.showMessageDialog(insertUserFrame, "All fields must be filled.", "Error", 0);
            }
        });
        insertUserFrame.setVisible(true);
    }

    private static JButton createStyledButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Arial", 1, 18));
        button.setBackground(new Color(255, 182, 193));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(255, 105, 180), 2));
        button.setPreferredSize(new Dimension(300, 50));
        button.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255, 105, 180), 2), BorderFactory.createEmptyBorder(10, 20, 10, 20)));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(255, 218, 185));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(255, 182, 193));
            }
        });
        button.addActionListener((e) -> button.setBackground(new Color(255, 105, 180)));
        button.setCursor(new Cursor(12));
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0, 40), 3));
        return button;
    }

    private static void openAddFrame() {
        final JFrame frame = new JFrame("Add Queries");
        frame.setDefaultCloseOperation(2);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(33, 33, 33));
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 10, 10));
        buttonPanel.setBackground(new Color(33, 33, 33));
        JButton insertUserButton = createStyledButtonn("insert a new user");
        buttonPanel.add(insertUserButton);
        insertUserButton.addActionListener((e) -> openInsertUserFrame());
        JButton enrollButton = createStyledButtonn("Enroll in Course");
        buttonPanel.add(enrollButton);
        enrollButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showEnrollmentDialog(frame);
            }
        });
        JButton feedbackButton = createStyledButtonn("FeedBack for a Course");
        buttonPanel.add(feedbackButton);
        feedbackButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showFeedbackDialog(frame);
            }
        });
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", 1, 14));
        backButton.setBackground(new Color(255, 99, 71));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.addActionListener((e) -> {
            frame.dispose();
            frame1.setVisible(true);
        });
        buttonPanel.add(backButton);
        frame.add(buttonPanel, "Center");
        frame.setLocationRelativeTo((Component)null);
        frame.setVisible(true);
    }

    private static void openUpdateFrame() {
        final JFrame frame = new JFrame("update Queries");
        frame.setDefaultCloseOperation(2);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(33, 33, 33));
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 10, 10));
        buttonPanel.setBackground(new Color(33, 33, 33));
        JButton fetchUserAssessmentsButton = createStyledButtonn("Update User Assessment Score");
        buttonPanel.add(fetchUserAssessmentsButton);
        fetchUserAssessmentsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showAssessmentUpdateDialog(frame);
            }
        });
        JButton updateScoreButton = createStyledButtonn("Update Score For Enrollemnt");
        buttonPanel.add(updateScoreButton);
        updateScoreButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showUpdateScoreDialog(frame);
            }
        });
        JButton applyDiscountButton = createStyledButtonn("Apply Discount for Students those Who have 2 course enroll");
        buttonPanel.add(applyDiscountButton);
        applyDiscountButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showApplyDiscountDialog(frame);
            }
        });
        JButton updateRatingButton = createStyledButtonn("Update Rating For instructor");
        buttonPanel.add(updateRatingButton);
        updateRatingButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showUpdateRatingDialog(frame);
            }
        });
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", 1, 14));
        backButton.setBackground(new Color(255, 99, 71));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.addActionListener((e) -> {
            frame.dispose();
            frame1.setVisible(true);
        });
        buttonPanel.add(backButton);
        frame.add(buttonPanel, "Center");
        frame.setLocationRelativeTo((Component)null);
        frame.setVisible(true);
    }

    public static void showAssessmentUpdateDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Update User Assessment Score", true);
        dialog.setSize(500, 300);
        dialog.setLayout(new GridLayout(4, 2));
        dialog.setDefaultCloseOperation(2);
        JLabel userIdLabel = new JLabel("Enter User ID:");
        final JTextField userIdField = new JTextField();
        JLabel assessmentLabel = new JLabel("Select Assessment:");
        final JComboBox<String> assessmentDropdown = new JComboBox();
        JLabel newScoreLabel = new JLabel("Enter Updated Score:");
        final JTextField newScoreField = new JTextField();
        JButton fetchButton = new JButton("Fetch Assessments");
        JButton updateButton = new JButton("Confirm Update");
        dialog.add(userIdLabel);
        dialog.add(userIdField);
        dialog.add(assessmentLabel);
        dialog.add(assessmentDropdown);
        dialog.add(newScoreLabel);
        dialog.add(newScoreField);
        dialog.add(fetchButton);
        dialog.add(updateButton);
        fetchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int userId = Integer.parseInt(userIdField.getText());
                    List<String[]> assessments = DatabaseQuery.retrieveUserAssessments(userId);
                    assessmentDropdown.removeAllItems();

                    for(String[] assessment : assessments) {
                        assessmentDropdown.addItem("AssessmentID: " + assessment[0] + " (ResultID: " + assessment[1] + "Score: " + assessment[2] + ")");
                    }

                    if (assessments.isEmpty()) {
                        JOptionPane.showMessageDialog(dialog, "No assessments found for this User ID.", "Information", 1);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int userId = Integer.parseInt(userIdField.getText());
                    String selectedItem = (String)assessmentDropdown.getSelectedItem();
                    if (selectedItem == null) {
                        JOptionPane.showMessageDialog(dialog, "Please select an assessment to update.", "Error", 0);
                        return;
                    }

                    String[] parts = selectedItem.split("\\s+");
                    int assessmentId = Integer.parseInt(parts[1].replace("AssessmentID:", "").trim());
                    double newScore = Double.parseDouble(newScoreField.getText());
                    DatabaseQuery.updateAssessmentScoreByUser(userId, assessmentId, newScore);
                    JOptionPane.showMessageDialog(dialog, "Score updated successfully!", "Success", 1);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    public static void showApplyDiscountDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Apply Discount", true);
        dialog.setSize(400, 200);
        dialog.setLayout(new GridLayout(2, 1));
        dialog.getContentPane().setBackground(new Color(240, 240, 240));
        JLabel infoLabel = new JLabel("Apply 20% discount to users enrolled in 3 or more courses?");
        infoLabel.setHorizontalAlignment(0);
        infoLabel.setForeground(new Color(0, 102, 204));
        dialog.add(infoLabel);
        JButton applyDiscountButton = new JButton("Apply Discount");
        applyDiscountButton.setBackground(new Color(34, 139, 34));
        applyDiscountButton.setForeground(Color.WHITE);
        dialog.add(applyDiscountButton);
        applyDiscountButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    DatabaseQuery.applyDiscountToEligibleUsers();
                    JOptionPane.showMessageDialog(dialog, "Discount applied successfully to eligible users!");
                    dialog.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    public static void showUpdateRatingDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Update Instructor Rating", true);
        dialog.setSize(400, 200);
        dialog.setLayout(new GridLayout(3, 2));
        dialog.getContentPane().setBackground(new Color(240, 240, 240));
        JLabel instructorIdLabel = new JLabel("Enter Instructor ID:");
        final JTextField instructorIdField = new JTextField();
        dialog.add(instructorIdLabel);
        dialog.add(instructorIdField);
        JButton updateButton = new JButton("Update Rating");
        updateButton.setBackground(new Color(34, 139, 34));
        updateButton.setForeground(Color.WHITE);
        dialog.add(new JLabel());
        dialog.add(updateButton);
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int instructorId = Integer.parseInt(instructorIdField.getText());
                    boolean success = DatabaseQuery.updateInstructorRating(instructorId);
                    if (success) {
                        JOptionPane.showMessageDialog(dialog, "Rating updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Rating not updated. Criteria not met or invalid ID.", "Info", 1);
                    }

                    dialog.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    public static void showUpdateScoreDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Update Enrollment Score", true);
        dialog.setSize(400, 250);
        dialog.setLayout(new GridLayout(4, 2));
        dialog.getContentPane().setBackground(new Color(240, 240, 240));
        JLabel enrollmentIdLabel = new JLabel("Enrollment ID:");
        final JTextField enrollmentIdField = new JTextField();
        JLabel courseIdLabel = new JLabel("Course ID:");
        final JTextField courseIdField = new JTextField();
        JLabel newScoreLabel = new JLabel("New Score (+20):");
        final JTextField newScoreField = new JTextField();
        enrollmentIdLabel.setForeground(new Color(0, 102, 204));
        courseIdLabel.setForeground(new Color(0, 102, 204));
        newScoreLabel.setForeground(new Color(0, 102, 204));
        dialog.add(enrollmentIdLabel);
        dialog.add(enrollmentIdField);
        dialog.add(courseIdLabel);
        dialog.add(courseIdField);
        dialog.add(newScoreLabel);
        dialog.add(newScoreField);
        JButton updateButton = new JButton("Update");
        updateButton.setBackground(new Color(34, 139, 34));
        updateButton.setForeground(Color.WHITE);
        dialog.add(new JLabel());
        dialog.add(updateButton);
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int enrollmentId = Integer.parseInt(enrollmentIdField.getText());
                    int courseId = Integer.parseInt(courseIdField.getText());
                    int currentScore = Integer.parseInt(newScoreField.getText());
                    DatabaseQuery.updateEnrollmentScore(enrollmentId, courseId, currentScore);
                    JOptionPane.showMessageDialog(dialog, "Score updated successfully!");
                    dialog.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    private static void openDeleteFrame() {
        final JFrame frame = new JFrame("Delete data");
        frame.setDefaultCloseOperation(2);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(33, 33, 33));
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 10, 10));
        buttonPanel.setBackground(new Color(33, 33, 33));
        JButton deleteUsersButton = createStyledButtonn("Manage Inactive Users");
        buttonPanel.add(deleteUsersButton);
        deleteUsersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showInactiveUsersDialog(frame);
            }
        });
        JButton deleteCoursesButton = new JButton("Delete Courses with Low Rating");
        buttonPanel.add(deleteCoursesButton);
        deleteCoursesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Mainn.showDeleteCoursesDialog(frame);
            }
        });
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", 1, 14));
        backButton.setBackground(new Color(255, 99, 71));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.addActionListener((e) -> {
            frame.dispose();
            frame1.setVisible(true);
        });
        buttonPanel.add(backButton);
        frame.add(buttonPanel, "Center");
        frame.setLocationRelativeTo((Component)null);
        frame.setVisible(true);
    }

    public static void showDeleteCoursesDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Delete Low Rated Courses", true);
        dialog.setSize(400, 250);
        dialog.setLayout(new GridLayout(3, 2));
        dialog.setDefaultCloseOperation(2);
        JLabel ratingLabel = new JLabel("Enter Rating Threshold (e.g., 3.0):");
        final JTextField ratingField = new JTextField();
        dialog.add(ratingLabel);
        dialog.add(ratingField);
        JButton fetchCoursesButton = new JButton("Fetch and Delete Courses");
        dialog.add(new JLabel());
        dialog.add(fetchCoursesButton);
        fetchCoursesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double rating = Double.parseDouble(ratingField.getText());
                    List<String[]> courses = DatabaseQuery.fetchCoursesForDeletion(rating);
                    if (courses.isEmpty()) {
                        JOptionPane.showMessageDialog(dialog, "No courses meet the criteria.", "Information", 1);
                    } else {
                        StringBuilder message = new StringBuilder("The following courses will be deleted:\n\n");

                        for(String[] course : courses) {
                            message.append("Course ID: ").append(course[0]).append(", Name: ").append(course[1]).append("\n");
                        }

                        message.append("\nDo you want to proceed?");
                        int confirm = JOptionPane.showConfirmDialog(dialog, message.toString(), "Confirm Deletion", 0);
                        if (confirm == 0) {
                            DatabaseQuery.deleteCourses(rating);
                            JOptionPane.showMessageDialog(dialog, "Courses deleted successfully!", "Success", 1);
                        }
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    public static void showInactiveUsersDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Inactive Users", true);
        dialog.setSize(600, 400);
        dialog.setLayout(new BorderLayout());
        JPanel inputPanel = new JPanel(new FlowLayout());
        JLabel label = new JLabel("Enter inactivity period (days):");
        final JTextField daysField = new JTextField(5);
        JButton fetchButton = new JButton("Fetch Users");
        inputPanel.add(label);
        inputPanel.add(daysField);
        inputPanel.add(fetchButton);
        String[] columnNames = new String[]{"User ID", "Name", "Join Date", "Role"};
        final DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable userTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(userTable);
        JPanel actionPanel = new JPanel(new FlowLayout());
        final JButton deleteButton = new JButton("Delete Selected Users");
        deleteButton.setEnabled(false);
        JButton closeButton = new JButton("Close");
        actionPanel.add(deleteButton);
        actionPanel.add(closeButton);
        dialog.add(inputPanel, "North");
        dialog.add(scrollPane, "Center");
        dialog.add(actionPanel, "South");
        fetchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int intervalDays = Integer.parseInt(daysField.getText());
                    List<String[]> users = DatabaseQuery.fetchInactiveUsers(intervalDays);
                    tableModel.setRowCount(0);

                    for(String[] user : users) {
                        tableModel.addRow(user);
                    }

                    deleteButton.setEnabled(!users.isEmpty());
                } catch (NumberFormatException var6) {
                    JOptionPane.showMessageDialog(dialog, "Please enter a valid number of days.", "Error", 0);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(dialog, "Are you sure you want to delete these users?", "Confirm Deletion", 0);
                if (confirmed == 0) {
                    try {
                        int intervalDays = Integer.parseInt(daysField.getText());
                        DatabaseQuery.deleteInactiveUsers(intervalDays);
                        JOptionPane.showMessageDialog(dialog, "Inactive users deleted successfully!");
                        dialog.dispose();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage(), "Error", 0);
                    }
                }

            }
        });
        closeButton.addActionListener((e) -> dialog.dispose());
        dialog.setVisible(true);
    }

    public static void showFeedbackDialog(JFrame parentFrame) {
        final JDialog dialog = new JDialog(parentFrame, "Give Feedback", true);
        dialog.setSize(400, 350);
        dialog.setLayout(new GridLayout(6, 2, 10, 10));
        dialog.getContentPane().setBackground(new Color(240, 240, 240));
        JLabel courseIdLabel = new JLabel("Course ID:");
        final JTextField courseIdField = new JTextField();
        JLabel userIdLabel = new JLabel("User ID:");
        final JTextField userIdField = new JTextField();
        JLabel ratingLabel = new JLabel("Rating (1-5):");
        final JTextField ratingField = new JTextField();
        JLabel commentsLabel = new JLabel("Comments:");
        final JTextArea commentsField = new JTextArea();
        JScrollPane commentsScroll = new JScrollPane(commentsField);
        courseIdLabel.setFont(new Font("Arial", 1, 14));
        userIdLabel.setFont(new Font("Arial", 1, 14));
        ratingLabel.setFont(new Font("Arial", 1, 14));
        commentsLabel.setFont(new Font("Arial", 1, 14));
        courseIdLabel.setForeground(new Color(33, 33, 33));
        userIdLabel.setForeground(new Color(33, 33, 33));
        ratingLabel.setForeground(new Color(33, 33, 33));
        commentsLabel.setForeground(new Color(33, 33, 33));
        courseIdField.setBackground(new Color(255, 255, 255));
        userIdField.setBackground(new Color(255, 255, 255));
        ratingField.setBackground(new Color(255, 255, 255));
        commentsField.setBackground(new Color(255, 255, 255));
        dialog.add(courseIdLabel);
        dialog.add(courseIdField);
        dialog.add(userIdLabel);
        dialog.add(userIdField);
        dialog.add(ratingLabel);
        dialog.add(ratingField);
        dialog.add(commentsLabel);
        dialog.add(commentsScroll);
        JButton submitButton = new JButton("Submit Feedback");
        submitButton.setBackground(new Color(0, 123, 255));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Arial", 1, 14));
        dialog.add(new JLabel());
        dialog.add(submitButton);
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int courseId = Integer.parseInt(courseIdField.getText());
                    int userId = Integer.parseInt(userIdField.getText());
                    int rating = Integer.parseInt(ratingField.getText());
                    String comments = commentsField.getText();
                    DatabaseQuery.insertFeedback(userId, courseId, rating, comments);
                    JOptionPane.showMessageDialog(dialog, "Feedback submitted successfully!", "Success", 1);
                    dialog.dispose();
                } catch (NumberFormatException var6) {
                    JOptionPane.showMessageDialog(dialog, "Please enter valid values!", "Error", 0);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Error submitting feedback: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        dialog.setVisible(true);
    }

    private static void openSelectQueriesFrame() {
        final JFrame frame = new JFrame("Select Queries");
        frame.setDefaultCloseOperation(2);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(33, 33, 33));
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(0, 1, 10, 10));
        buttonPanel.setBackground(new Color(33, 33, 33));
        JButton queryButton1 = createStyledButtonn("Fetch Users Without Enrollments");
        JButton queryButton2 = createStyledButtonn("Fetch All Users");
        JButton queryButton3 = createStyledButtonn("Fetch Top 5 by Course ID");
        JButton queryButton4 = createStyledButtonn("Fetch Courses By Category With Enrollments");
        JButton queryButton5 = createStyledButtonn("Get User Count");
        JButton queryButton6 = createStyledButtonn("Best Instructor");
        JButton queryButton7 = createStyledButtonn("Instructor Ratings");
        JButton queryButton8 = createStyledButtonn("Completed Courses For User");
        JButton queryButton9 = createStyledButtonn("Fetch Feedback for a Course");
        JButton queryButton10 = createStyledButtonn("Average Score for Assessments (Course)");
        JButton queryButton11 = createStyledButtonn("Fetch Discounted Users");
        buttonPanel.add(queryButton1);
        buttonPanel.add(queryButton2);
        buttonPanel.add(queryButton3);
        buttonPanel.add(queryButton4);
        buttonPanel.add(queryButton5);
        buttonPanel.add(queryButton6);
        buttonPanel.add(queryButton7);
        buttonPanel.add(queryButton8);
        buttonPanel.add(queryButton9);
        buttonPanel.add(queryButton11);
        buttonPanel.add(queryButton10);
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", 1, 14));
        backButton.setBackground(new Color(255, 99, 71));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.addActionListener((e) -> {
            frame.dispose();
            frame1.setVisible(true);
        });
        buttonPanel.add(backButton);
        frame.add(buttonPanel, "West");
        final DefaultTableModel model = new DefaultTableModel();
        JTable table = new JTable(model);
        table.setBackground(new Color(240, 240, 240));
        table.setForeground(Color.DARK_GRAY);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, "Center");
        model.addColumn("Name");
        model.addColumn("Score");
        queryButton1.addActionListener((e) -> {
            try {
                DatabaseQuery.fetchUsersWithoutEnrollments(model);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", 0);
            }

        });
        queryButton2.addActionListener((e) -> {
            try {
                DatabaseQuery.fetchAllUsers(model);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", 0);
            }

        });
        queryButton3.addActionListener((e) -> {
            String courseIdStr = JOptionPane.showInputDialog(frame, "Enter Course ID:");

            try {
                int courseId = Integer.parseInt(courseIdStr);
                DatabaseQuery.fetchTop5ByCourseID(model, courseId);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ((Exception)ex).getMessage(), "Error", 0);
            }

        });
        queryButton4.addActionListener((e) -> {
            try {
                DatabaseQuery.fetchCoursesByCategoryWithEnrollments(model);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", 0);
            }

        });
        queryButton5.addActionListener((e) -> {
            try {
                DatabaseQuery.fetchUserCount(model);
                JOptionPane.showMessageDialog(frame, "User count fetched successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", 0);
            }

        });
        queryButton6.addActionListener((e) -> {
            String courseIdStr = JOptionPane.showInputDialog(frame, "Enter Course ID:");

            try {
                int courseId = Integer.parseInt(courseIdStr);
                DatabaseQuery.fetchBestInstructorByCourseID(model, courseId);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ((Exception)ex).getMessage(), "Error", 0);
            }

        });
        queryButton7.addActionListener((e) -> {
            try {
                DatabaseQuery.fetchInstructorRatings(model);
                JOptionPane.showMessageDialog(frame, "Instructor ratings fetched successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", 0);
            }

        });
        queryButton8.addActionListener((e) -> {
            String userIdStr = JOptionPane.showInputDialog(frame, "Enter User ID:");

            try {
                int userId = Integer.parseInt(userIdStr);
                DatabaseQuery.fetchCompletedCoursesForUser(model, userId);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ((Exception)ex).getMessage(), "Error", 0);
            }

        });
        queryButton11.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    DatabaseQuery.fetchDiscountedUsers(model);
                    JOptionPane.showMessageDialog(frame, "Discounted Users");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", 0);
                }

            }
        });
        queryButton9.addActionListener((e) -> {
            String courseIdStr = JOptionPane.showInputDialog(frame, "Enter Course ID:");

            try {
                int courseId = Integer.parseInt(courseIdStr);
                DatabaseQuery.fetchFeedbackForCourse(model, courseId);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ((Exception)ex).getMessage(), "Error", 0);
            }

        });
        queryButton10.addActionListener((e) -> {
            String courseIdStr = JOptionPane.showInputDialog(frame, "Enter Course ID:");

            try {
                int courseId = Integer.parseInt(courseIdStr);
                DatabaseQuery.fetchAverageScoreForAssessmentsByCourse(model, courseId);
                JOptionPane.showMessageDialog(frame, "Data fetched successfully!");
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(frame, "Error fetching data: " + ((Exception)ex).getMessage(), "Error", 0);
            }

        });
        frame.setLocationRelativeTo((Component)null);
        frame.setVisible(true);
    }

    private static JButton createStyledButtonn(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Arial", 1, 14));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(Cursor.getPredefinedCursor(12));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(100, 149, 237));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(70, 130, 180));
            }
        });
        return button;
    }

    //Register:
    private static void showRegisterForm() {
        JFrame registerFrame = new JFrame("Register");
        registerFrame.setSize(700, 500);
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        registerFrame.setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(60, 179, 113), 0, getHeight(), new Color(245, 255, 250));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new GridBagLayout());

        Font font = new Font("Segoe UI", Font.PLAIN, 16);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(20);
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        JTextField dobField = new JTextField(20);
        JLabel roleLabel = new JLabel("Role:");
        JTextField roleField = new JTextField(20);
        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        JLabel[] labels = {nameLabel, emailLabel, passwordLabel, dobLabel, roleLabel};
        for (JLabel label : labels) label.setFont(font);

        JTextField[] fields = {nameField, emailField, dobField, roleField};
        for (JTextField field : fields) field.setFont(font);

        passwordField.setFont(font);
        registerButton.setFont(font);
        backButton.setFont(font);

        registerButton.setBackground(new Color(0, 123, 255));
        registerButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(255, 99, 71));
        backButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        backButton.setFocusPainted(false);

        gbc.gridx = 0; gbc.gridy = 0;
        mainPanel.add(nameLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        mainPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        mainPanel.add(passwordLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(passwordField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        mainPanel.add(dobLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(dobField, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        mainPanel.add(roleLabel, gbc);
        gbc.gridx = 1;
        mainPanel.add(roleField, gbc);

        gbc.gridx = 0; gbc.gridy = 5;
        mainPanel.add(backButton, gbc);
        gbc.gridx = 1;
        mainPanel.add(registerButton, gbc);

        registerFrame.add(mainPanel);
        registerFrame.setVisible(true);

        registerButton.addActionListener(e -> {
            try {
                DatabaseQuery.insertUser(
                        nameField.getText(),
                        emailField.getText(),
                        new String(passwordField.getPassword()),
                        dobField.getText(),
                        roleField.getText()
                );
                JOptionPane.showMessageDialog(registerFrame, "User registered successfully!");
                registerFrame.dispose();
                showLoginForm();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(registerFrame, "Error: " + ex.getMessage());
            }
        });

        backButton.addActionListener(e -> {
            registerFrame.dispose();
            showEntryChoice();
        });
    }

    //    Entry:
    private static void showEntryChoice() {
        JFrame entryFrame = new JFrame("Welcome - Course Platform");
        entryFrame.setSize(600, 300);
        entryFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        entryFrame.setLocationRelativeTo(null);
        entryFrame.setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(70, 130, 180), 0, getHeight(), new Color(230, 230, 250));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new GridBagLayout());

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginBtn.setBackground(new Color(0, 123, 255));
        registerBtn.setBackground(new Color(60, 179, 113));
        loginBtn.setForeground(Color.WHITE);
        registerBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        registerBtn.setFocusPainted(false);
        loginBtn.setPreferredSize(new Dimension(150, 50));
        registerBtn.setPreferredSize(new Dimension(150, 50));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);

        gbc.gridx = 0; gbc.gridy = 0;
        mainPanel.add(loginBtn, gbc);
        gbc.gridx = 1;
        mainPanel.add(registerBtn, gbc);

        entryFrame.add(mainPanel, BorderLayout.CENTER);
        entryFrame.setVisible(true);

        // Actions
        loginBtn.addActionListener(e -> {
            entryFrame.dispose();
            showLoginForm();  // Show login form
        });

        registerBtn.addActionListener(e -> {
            entryFrame.dispose();
            showRegisterForm();  // Show register form
        });
    }



// Login:
private static void showLoginForm() {
    JFrame loginFrame = new JFrame("Login");
    loginFrame.setSize(600, 400);
    loginFrame.setLocationRelativeTo(null);
    loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    loginFrame.setLayout(new BorderLayout());

    // Gradient background panel
    JPanel mainPanel = new JPanel() {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            GradientPaint gp = new GradientPaint(0, 0, new Color(50, 150, 250), 0, getHeight(), new Color(230, 230, 250));
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }
    };
    mainPanel.setLayout(new GridBagLayout());

    JLabel emailLabel = new JLabel("Email:");
    JTextField emailField = new JTextField(20);
    JLabel passwordLabel = new JLabel("Password:");
    JPasswordField passwordField = new JPasswordField(20);
    JButton loginButton = new JButton("Login");
    JButton backButton = new JButton("Back");

    // Styling
    Font font = new Font("Segoe UI", Font.PLAIN, 16);
    emailLabel.setFont(font);
    passwordLabel.setFont(font);
    loginButton.setFont(font);
    backButton.setFont(font);
    loginButton.setBackground(new Color(0, 123, 255));
    loginButton.setForeground(Color.WHITE);
    backButton.setBackground(new Color(255, 99, 71));
    backButton.setForeground(Color.WHITE);
    loginButton.setFocusPainted(false);
    backButton.setFocusPainted(false);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.fill = GridBagConstraints.HORIZONTAL;

    gbc.gridx = 0; gbc.gridy = 0;
    mainPanel.add(emailLabel, gbc);
    gbc.gridx = 1;
    mainPanel.add(emailField, gbc);

    gbc.gridx = 0; gbc.gridy = 1;
    mainPanel.add(passwordLabel, gbc);
    gbc.gridx = 1;
    mainPanel.add(passwordField, gbc);

    gbc.gridx = 0; gbc.gridy = 2;
    mainPanel.add(backButton, gbc);
    gbc.gridx = 1;
    mainPanel.add(loginButton, gbc);

    loginFrame.add(mainPanel);
    loginFrame.setVisible(true);

    loginButton.addActionListener(e -> {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        try {
            if (DatabaseQuery.validateLogin(email, password)) {
                loginFrame.dispose();
                frame1.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Invalid credentials!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(loginFrame, "Error: " + ex.getMessage());
        }
    });

    backButton.addActionListener(e -> {
        loginFrame.dispose();
        showEntryChoice();
    });
}



}

